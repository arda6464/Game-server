using System;

public static class NotificationSender
{
    public static void Send(Session session, Notification notification)
    {
        if (session == null)
        {
            Logger.errorslog("[NotificationSender] Session null, gönderim yapılamadı.");
            return;
        }

        var packet = new NotificationPacket
        { 
            IndexID = notification.IndexID,
            Type = notification.type,
            Title = notification.Title,
            Message = notification.Message,
            IconId = notification.iconid,
            ButtonText = notification.ButtonText,
            Url = notification.Url,
            Sender = notification.Sender,
            IsViewed = notification.IsViewed,
            UnixTime = new DateTimeOffset(notification.Timespam.ToUniversalTime()).ToUnixTimeSeconds(),
            IsClaimed = notification.IsClaimed,
            Rewards = notification.Rewards
        };

        session.Send(packet);

        Logger.genellog($"[NotificationSender] Bildirim gönderildi: {notification.Message}");
    }
    
   
}
