using System.Linq;
using Newtonsoft.Json;

[HttpController]
public class PlayersController : BaseController
{
    [HttpRoute("GET", "/api/players", RequiresAuth = true)]
    public object GetPlayers()
    {
        try
        {
            var players = PlayerManager.GetPlayers();
            if (players == null || !players.Any())
                return NotFound("Oyuncu bulunamadı.");

            return Ok(players.Select(p => new
            {
                id = p.Id,
                username = p.Username,
                level = p.Level,
                status = p.Status,
                lastLogin = p.LastLogin > DateTime.MinValue ? p.LastLogin.ToString("dd.MM.yyyy HH:mm") : "Hiç giriş yapmadı",
                lastIp = p.LastIp ?? "N/A"
            }).ToList());
        }
        catch (Exception ex)
        {
            return Fail("Oyuncular getirilirken bir hata oluştu: " + ex.Message);
        }
    }

    [HttpRoute("GET", "/api/players/{id}", RequiresAuth = true)]
    public object GetPlayer(string id)
    {
        try
        {
            var player = PlayerManager.GetPlayer(id);
            if (player == null)
                return NotFound("Oyuncu bulunamadı.");

            return Ok(new
            {
                id = player.Id,
                username = player.Username,
                level = player.Level,
                status = player.Status,
                lastLogin = player.LastLogin > DateTime.MinValue ? player.LastLogin.ToString("dd.MM.yyyy HH:mm") : "Hiç giriş yapmadı",
                lastIp = player.LastIp ?? "N/A",
                inventory = player.Inventory,
                achievements = player.Achievements
            });
        }
        catch (Exception ex)
        {
            return Fail("Oyuncu getirilirken bir hata oluştu: " + ex.Message);
        }
    }

    [HttpRoute("POST", "/api/players", RequiresAuth = true)]
    public object CreatePlayer()
    {
        try
        {
            var data = ReadFormData();
            if (data == null || !data.ContainsKey("username"))
                return Fail("Kullanıcı adı gerekli.");

            string username = data["username"].Trim();
            string? password = data.ContainsKey("password") ? data["password"] : null;

            var player = PlayerManager.CreatePlayer(username, password);
            if (player == null)
                return Fail("Bu kullanıcı adı zaten mevcut.");

            Audit("Oyuncu Oluşturuldu", username, $"ID: {player.Id}");
            return Ok(new { success = true, message = "Oyuncu oluşturuldu.", playerId = player.Id });
        }
        catch (Exception ex)
        {
            return Fail("Oyuncu oluşturulurken bir hata oluştu: " + ex.Message);
        }
    }

    [HttpRoute("POST", "/api/players/{id}/update", RequiresAuth = true)]
    public object UpdatePlayer(string id)
    {
        try
        {
            var player = PlayerManager.GetPlayer(id);
            if (player == null)
                return NotFound("Oyuncu bulunamadı.");

            var data = ReadFormData();
            if (data == null)
                return Fail("Güncellenecek veri bulunamadı.");

            string? username = data.ContainsKey("username") ? data["username"].Trim() : null;
            string? status = data.ContainsKey("status") ? data["status"] : null;
            int? level = data.ContainsKey("level") ? int.Parse(data["level"]) : null;

            bool updated = PlayerManager.UpdatePlayer(id, username, status, level);
            if (!updated)
                return Fail("Oyuncu güncellenemedi.");

            Audit("Oyuncu Güncellendi", id, $"Yeni kullanıcı adı: {username ?? player.Username}");
            return Ok(new { success = true, message = "Oyuncu güncellendi." });
        }
        catch (Exception ex)
        {
            return Fail("Oyuncu güncellenirken bir hata oluştu: " + ex.Message);
        }
    }

    [HttpRoute("POST", "/api/players/{id}/delete", RequiresAuth = true)]
    public object DeletePlayer(string id)
    {
        try
        {
            var player = PlayerManager.GetPlayer(id);
            if (player == null)
                return NotFound("Oyuncu bulunamadı.");

            bool deleted = PlayerManager.DeletePlayer(id);
            if (!deleted)
                return Fail("Oyuncu silinemedi.");

            Audit("Oyuncu Silindi", id, $"Kullanıcı adı: {player.Username}");
            return Ok(new { success = true, message = "Oyuncu silindi." });
        }
        catch (Exception ex)
        {
            return Fail("Oyuncu silinirken bir hata oluştu: " + ex.Message);
        }
    }
}