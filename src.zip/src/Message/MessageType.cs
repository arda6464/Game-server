public enum MessageType : short
{
    #region Conntection
    FirstConnectionRequest,
    FirstConnectionResponse,
    Disconnect,
    Ping,
    Pong,
    Maintance,
    MessageCode,
    Alive,
    Presence,
    ClientErrorRequest,

    // UDP tipleri artık UdpMessageType.cs dosyasında (byte olarak)
    #endregion

    #region Authentication
    AuthLoginRequest,
    AuthLoginResponse,
    NewAccountCreateResponse,
    #endregion
    #region  Account
    AccountData,
    LoginFailed,
    LoginOKRequest,
    LoginOKResponse,
    SendVerifyCode,
    VerifyCodeResponse,
    AccountLogin,
    SignAccount,
    ChangeNotficationRequest,
    NameNotAcceptedRequest,
    #endregion


    #region  Profile
    ChangeNameRequest,
    ChangeNameResponse,
    ChangeNameColorRequest,
    ChangeNameColorResponse,
    SetAvatarRequest,
    SetAvatarResponse,
    ShowProfileRequest,
    ShowProfileResponse,
    #endregion


    #region  Social
    SocialSettingsHasChanged,
    SocialSettingsHasChangedResponse,
    OnlinePlayerStateChanged,

    #endregion 





    #region  Friends
    SendFriendRequest,
    AcceptFriendRequest,
    NewRequest,
    ShowFriendRequest,
    ShowFriendResponse,
    AcceptFriendResponse,
    DeclineFriendRequest,
    DeclineFriendResponse,
    DeleteFriendRequest,
    DeleteFriendResponse,
    BestFriendChanged,
    #endregion


    #region  Team
    CreateTeamRequest,
    CreateTeamResponse,
    JoinTeamRequest,
    JoinTeamResponse,
    LeaveTeamRequest,
    LeaveTeamResponse,
    SendTeamMessageRequest,
    SendTeamMessageResponse,
    InvitePlayerTeamRequest,
    InvitePlayerTeamResponse,
    InviteToTeamRequest,
    InviteToTeamResponse,
    #endregion





    #region  notfications
    Notification,
    AllNotficationViewed,
    ClaimInboxRewardRequest,
    ClaimInboxRewardResponse,
    #endregion

    #region  Leaderboards
    LeaderboardRequest,
    LeaderboardResponse,
    #endregion



    #region  Club

    ClubCreateRequest,
    ClubCreateResponse,
    GetRandomClubRequest,
    GetRandomClubResponse,
    ClubShowRequest,
    ClubShowResponse,
    SendClubMessage,
    GetClubMessage,
    JoinClubRequest,
    JoinClubResponse,
    LeaveClubRequest,
    LeaveClubResponse,
    ClubEditRequest,
    ClubEditResponse,
    ClubSearchRequest,
    ClubSearchResponse,
    KickMemberinClubRequest,
    KickMemberinClubResponse,
    MemberToUpperRequest,
    MemberToUpperResponse,
    MemberToLowerRequest,
    MemberToLowerResponse,
    ClubJoinRespondRequest,
    ClubRequestStateUpdate,

    #endregion



    #region  Battle
    MatchMakingRequest,
    MatchMakingCancelRequest,
    MatchFound,
    MatchMakingUpdate,
    StartMatch,
    Move,

   

    #endregion

    #region  Shop
    GetAllMarketItemsRequest,
    GetAllMarketItemsResponse,
    BuyMarketItemRequest,
    BuyMarketItemResponse,

    #endregion



    #region  Support
    SupportMessageSend,
    SupportMessageResponse,
    SupporCreateTicketRequest,
    SupporCreateTicketResponse,
    ReportPlayerRequest,
    SupportGetAllTicketRequest,
    SupportGetAllTicketResponse,
    SupportTicketClosed,
    SupportTicketOpened,

    #endregion

    #region Pass
    NewQuest,
    DeleteQuest,
    QuestProgress,

    #endregion

    #region Invite
    JoinByInviteRequest,
    #endregion

    

    #region  Android
    NewFBNTokenRequest,
    #endregion




    #region Events
    GetEvents,
    DeleteEvent,
    EventsResponse,
    AddEvent,
    GachaResponse,
    #endregion

    #region News
    GetUpdateNotesRequest,
    GetUpdateNotesResponse,
    #endregion

}
