public class Role
{
    public enum Roles

    {
        Owner,
        Staff,
        Admin,
        Moderator,
        VIP,
        Premium,
        Donator,
    }
}