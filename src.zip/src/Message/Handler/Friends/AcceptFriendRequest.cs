[PacketHandler(MessageType.AcceptFriendRequest)]
public static class FriendRequestAccept
{
    public static void Handle(Session session, byte[] message)
    {
        using (var bb = ByteBufferPool.Get())
        {
            bb.WriteBytes(message, true);
            var packet = new FriendRequestAcceptPacket();
            packet.Deserialize(bb);

            if (session.Account == null) return;
            var target = AccountCache.Load(packet.TargetId);
            if (target == null)
            {
                Logger.errorslog($"[FriendRequestAccept] {packet.TargetId} bulunamadı");
                return;
            }

            FriendsManager.AcceptRequest(session.Account, target, session);
        }
    }
}
