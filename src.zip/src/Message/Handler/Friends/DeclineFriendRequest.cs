[PacketHandler(MessageType.DeclineFriendRequest)]
public static class FriendRequestDecline
{
    public static void Handle(Session session, byte[] message)
    {
        using (var bb = ByteBufferPool.Get())
        {
            bb.WriteBytes(message, true);
            var packet = new FriendRequestDeclinePacket();
            packet.Deserialize(bb);

            if (session.Account == null) return;
            var target = AccountCache.Load(packet.TargetId);
            if (target == null)
            {
                Logger.errorslog("[FriendRequestDecline] hedef hesap bulunamadı");
                return;
            }

            FriendsManager.DeclineRequest(session.Account, target);
        }
    }
}
