[PacketHandler(MessageType.BestFriendChanged)]
public static class BestFriendHandler
{
    public static void Handle(Session session, byte[] data)
    {
        using (var bb = ByteBufferPool.Get())
        {
            bb.WriteBytes(data);
            bb.ReadVarInt();
            int targetId = bb.ReadVarInt();

            if (session.Account == null) return;
            FriendsManager.SetBestFriend(session.Account, targetId);
        }
    }
}
