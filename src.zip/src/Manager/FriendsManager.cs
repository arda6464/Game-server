public class FriendInfo
{
    public string? Id { get; set; }
    public string? Username { get; set; }
    public int AvatarId { get; set; }
    public int NameColorID { get; set; }

     }
